Made with http://rolladvantage.com/tokenstamp/

It ended up just being faster than monkeying around in photoshop, but also I'm bad at photoshop. �\_(?)_/�